// api/health.js — Test endpoint
module.exports = function handler(req, res) {
  res.status(200).json({
    status: 'ok',
    time: new Date().toISOString(),
    env: {
      openai: process.env.OPENAI_API_KEY ? 'configurée' : 'MANQUANTE',
      serper: process.env.SERPER_API_KEY ? 'configurée' : 'MANQUANTE'
    }
  });
};
