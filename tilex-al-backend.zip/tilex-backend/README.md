# 🔥 TI-LEX-AL Backend

Backend serverless pour la plateforme IA **TI-LEX-AL / ALEXGPT**.  
Déployé sur **Vercel** avec **GPT-4o-mini** d'OpenAI.

---

## 📁 Structure

```
tilex-backend/
├── api/
│   ├── chat.js      ← Endpoint /api/chat (GPT-4o-mini)
│   └── search.js    ← Endpoint /api/search (recherche web)
├── vercel.json       ← Config Vercel
├── package.json
└── README.md
```

---

## 🚀 Déploiement en 4 étapes

### 1. Créer un compte Vercel
→ https://vercel.com (gratuit avec GitHub)

### 2. Obtenir une clé OpenAI
→ https://platform.openai.com/api-keys
→ Créer une clé API et la copier

### 3. Déployer sur Vercel

**Option A — Via GitHub (recommandé) :**
1. Pousse ce dossier sur un repo GitHub
2. Va sur https://vercel.com/new
3. Importe le repo
4. Dans "Environment Variables", ajoute :
   - `OPENAI_API_KEY` = ta clé OpenAI
5. Clique "Deploy"

**Option B — Via CLI :**
```bash
npm i -g vercel
cd tilex-backend
vercel login
vercel --prod
# Quand demandé, ajoute la variable d'environnement:
vercel env add OPENAI_API_KEY
```

### 4. Configurer le Frontend
Une fois déployé, Vercel te donne une URL genre :
`https://tilex-al-backend.vercel.app`

Dans ton fichier HTML (tilex.html), mets à jour :
```javascript
var API_URL = "https://tilex-al-backend.vercel.app";
```

Si le frontend ET le backend sont sur le même projet Vercel,
laisse `API_URL = ""` (vide = même domaine).

---

## 🔧 Variables d'environnement

| Variable | Requis | Description |
|----------|--------|-------------|
| `OPENAI_API_KEY` | ✅ Oui | Clé API OpenAI |

---

## 📡 API Endpoints

### POST /api/chat
Corps JSON :
```json
{
  "message": "Salut, comment ça va ?",
  "agent": {
    "name": "TI-LEX-AL",
    "personality": "Fun & Hardcore",
    "specialty": "Tout",
    "is_master": true
  },
  "history": [
    { "role": "user", "content": "Hey" },
    { "role": "assistant", "content": "Yo boss!" }
  ]
}
```

Réponse :
```json
{
  "reply": "🔥 Yo! Ça va grave bien boss! Qu'est-ce que je peux faire pour toi ?"
}
```

### POST /api/search
Corps JSON :
```json
{
  "query": "intelligence artificielle 2025",
  "max_results": 5
}
```

---

## 💰 Coûts
- **Vercel** : Gratuit (hobby plan, suffisant pour commencer)
- **OpenAI GPT-4o-mini** : ~$0.15 / million de tokens input, ~$0.60 / million output
  → Très économique! ~1000 messages pour < $1

---

🔥 Built by TI-LEX-AL
