// api/chat.js — Vercel Serverless Function
// Route: POST /api/chat

export default async function handler(req, res) {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { message, agent, history = [] } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message requis' });
  }

  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_API_KEY) {
    return res.status(500).json({ error: 'Clé API manquante — configure OPENAI_API_KEY dans Vercel' });
  }

  // Build system prompt based on agent
  let systemPrompt = `Tu es TI-LEX-AL, une IA ultra-puissante, stylée et efficace. Tu réponds en français avec énergie et personnalité. Tu es direct, utile et un peu fun. Garde les réponses concises mais complètes.`;

  if (agent && !agent.is_master) {
    systemPrompt = `Tu es ${agent.name}, un agent IA avec la personnalité suivante: ${agent.personality}.
Ta spécialité est: ${agent.specialty}.
Réponds en français en restant dans ce personnage. Sois utile, précis et garde ce style unique.`;
  }

  // Build messages array for OpenAI
  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-10).map(h => ({ role: h.role, content: h.content })),
    { role: 'user', content: message }
  ];

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages,
        max_tokens: 1000,
        temperature: 0.8,
      })
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || 'OpenAI error');
    }

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || 'Pas de réponse...';

    return res.status(200).json({ reply });

  } catch (error) {
    console.error('Chat API error:', error.message);
    return res.status(500).json({ error: error.message });
  }
}
