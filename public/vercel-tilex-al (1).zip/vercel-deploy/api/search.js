// api/search.js — Vercel Serverless Function
// Route: POST /api/search

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { query, max_results = 5 } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query requise' });
  }

  const SERPER_API_KEY = process.env.SERPER_API_KEY;

  // Si pas de clé Serper, retourner des résultats simulés réalistes
  if (!SERPER_API_KEY) {
    const mockResults = generateMockResults(query, max_results);
    return res.status(200).json({ results: mockResults, source: 'mock' });
  }

  try {
    // Appel à Serper.dev (Google Search API — gratuit 2500 requêtes/mois)
    const response = await fetch('https://google.serper.dev/search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': SERPER_API_KEY
      },
      body: JSON.stringify({ q: query, num: max_results, gl: 'fr', hl: 'fr' })
    });

    if (!response.ok) throw new Error('Serper API error');

    const data = await response.json();

    const results = (data.organic || []).slice(0, max_results).map((item, i) => ({
      title: item.title,
      url: item.link,
      snippet: item.snippet || '',
      position: i + 1
    }));

    return res.status(200).json({ results, source: 'google' });

  } catch (error) {
    console.error('Search API error:', error.message);
    // Fallback silencieux
    const mockResults = generateMockResults(query, max_results);
    return res.status(200).json({ results: mockResults, source: 'mock' });
  }
}

function generateMockResults(query, count) {
  const sources = [
    { domain: 'wikipedia.org', label: 'Wikipedia' },
    { domain: 'reddit.com', label: 'Reddit' },
    { domain: 'medium.com', label: 'Medium' },
    { domain: 'stackoverflow.com', label: 'Stack Overflow' },
    { domain: 'github.com', label: 'GitHub' },
  ];
  return sources.slice(0, count).map((s, i) => ({
    title: `${s.label} — ${query}`,
    url: `https://${s.domain}/search?q=${encodeURIComponent(query)}`,
    snippet: `Résultats et informations sur "${query}" sur ${s.label}.`,
    position: i + 1
  }));
}
